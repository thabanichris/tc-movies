<footer class="text-center">
    <div class="container">        
        <div class="social">
            <a href="https://wa.me/27845318336" target="_blank"><span class="icon"><i class="fa fa-whatsapp"></i></a></span>
            <a href="https://instagram.com/tolow_developer/" target="_blank"><i class="fa fa-instagram"></i></a>
            <a href="https://github.com/thabanichris/" target="_blank"><i class="fa fa-github-square"></i></a>
        </div>
        <p>&copy; 2022 All Rights Reserved.</p>
    </div>
</footer>

<!-- js-min -->
<script src="assets/js/jquery-3.6.0.min.js"></script>
<!-- JS bootstrap -->
<script src="assets/js/bootstrap.min.js"></script>